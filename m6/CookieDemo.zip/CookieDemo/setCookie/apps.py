from django.apps import AppConfig


class SetcookieConfig(AppConfig):
    name = 'setCookie'
