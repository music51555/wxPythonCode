from django.shortcuts import render,HttpResponse,redirect
from app01.models import *

def books(request):
    num=1
    total_book=[]
    ret=Book.objects.all()
    # 查询出所有书籍的queryset对象，按属性key存储在字典中，每一个字典对应一本书的信息，将所有书籍的字典信息存储在列表中，便于在html网页中循环输出每一本的信息
    for book_obj in ret:
        per_book = {}
        nid=book_obj.nid
        title=book_obj.title
        price=book_obj.price
        pubdate=book_obj.pubdate
        publish=book_obj.publish.name
        authors=book_obj.authors.all()
        per_book['nid']=nid
        per_book['num']=num
        per_book['title']=title
        per_book['price']=price
        per_book['pubdate']=pubdate
        per_book['publish']=publish
        per_book['authors']=authors
        total_book.append(per_book)
        num+=1
    print(total_book)
    return render(request,'books.html',locals())

def addbook(request):
    if request.method == 'POST':
        print(request.POST)
        title=request.POST.get('title')
        price=request.POST.get('price')
        pubdate=request.POST.get('pubdate')
        publish=request.POST.get('publish')
        # 在HTML的select标签中选择了多个值，那么在request.POST中传递过来的是个列表
        author=request.POST.getlist('author')
        publish_obj=Publish.objects.get(name=publish)
        book_obj=Book.objects.filter(title=title).first()
        if book_obj:
            Book.objects.filter(title=title).update(title=title,price=price,pubdate=pubdate,publish=publish_obj)
        else:
            book_obj=Book.objects.create(title=title,price=price,pubdate=pubdate,publish=publish_obj)
        book_obj.authors.clear()
        for name in author:
            author_obj=Author.objects.filter(name=name).first()
            book_obj.authors.add(author_obj)
        return redirect('/books/')
    titles=Book.objects.values_list('title')
    author_objs=Author.objects.all()
    publish_names=Publish.objects.all().values('name')
    return render(request,'addbook.html',locals())

def delbook(request,nid):
    book_obj=Book.objects.filter(nid=nid).first()
    print(book_obj)
    book_obj.authors.clear()
    Book.objects.filter(nid=nid).first().delete()

    return redirect('/books')

def uptbook(request,nid):
    if request.method == 'POST':
        print('nonono',request.POST)
        title=request.POST.get('title')
        price=request.POST.get('price')
        pubdate=request.POST.get('pubdate')
        publish=request.POST.get('publish')
        publish_obj=Publish.objects.filter(name=publish).first()
        author_list=request.POST.getlist('author')
        book_obj=Book.objects.filter(title=title).first()
        if book_obj:
            Book.objects.filter(title=title).update(title=title, price=price, pubdate=pubdate, publish_id=publish_obj)
        else:
            book_obj=Book.objects.create(title=title, price=price, pubdate=pubdate, publish_id=publish_obj.nid)
        book_obj.authors.clear()
        for author in author_list:
            author_obj=Author.objects.filter(name=author).first()
            book_obj.authors.add(author_obj)
        return redirect('/books')
    book_obj=Book.objects.filter(nid=nid).first()
    nid = book_obj.nid
    title = book_obj.title
    price = book_obj.price
    pubdate = book_obj.pubdate
    publish_names=Publish.objects.all()
    publish_name = book_obj.publish
    author_names = Author.objects.all()
    book_author = book_obj.authors.all()
    print(author_names)
    return render(request,'addbook.html',locals())