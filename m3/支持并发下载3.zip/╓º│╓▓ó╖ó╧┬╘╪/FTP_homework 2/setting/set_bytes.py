def set_bytes(file_size):
    #将传入的字节转换成MB
    return round(file_size / 1000000,2)