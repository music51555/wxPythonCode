def read_file(filename,mode):
    f = open(filename,mode)
    return f

def write_file(filename,mode):
    f = open(filename,mode)
    return f